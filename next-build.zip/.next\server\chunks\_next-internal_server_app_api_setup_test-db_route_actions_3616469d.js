module.exports=[61253,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_setup_test-db_route_actions_3616469d.js.map