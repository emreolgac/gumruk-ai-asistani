module.exports=[38435,a=>{a.v({Index:{title:"Gümrük AI Asistanı",description:"Yapay zeka desteğiyle gümrük beyannamelerinizi saniyeler içinde hazırlayın.",uploadButton:"Belge Yükle",analyzeButton:"Analiz Et"},Auth:{login:"Giriş Yap",register:"Kayıt Ol",logout:"Çıkış Yap"}})}];

//# sourceMappingURL=messages_tr_json_0bd12e11._.js.map