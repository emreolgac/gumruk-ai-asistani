module.exports=[66291,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_%28auth%29_login_page_actions_e6579d71.js.map