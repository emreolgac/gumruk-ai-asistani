module.exports=[50929,a=>{a.v({Index:{title:"Customs AI Assistant",description:"Prepare your customs declarations in seconds with AI support.",uploadButton:"Upload Document",analyzeButton:"Analyze"},Auth:{login:"Login",register:"Register",logout:"Logout"}})}];

//# sourceMappingURL=messages_en_json_a7997480._.js.map