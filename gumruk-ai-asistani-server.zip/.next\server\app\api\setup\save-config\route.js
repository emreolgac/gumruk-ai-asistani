var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/setup/save-config/route.js")
R.c("server/chunks/[root-of-the-server]__da28eb83._.js")
R.c("server/chunks/[root-of-the-server]__6ac8ec31._.js")
R.c("server/chunks/_next-internal_server_app_api_setup_save-config_route_actions_ddb0b35b.js")
R.m(36328)
module.exports=R.m(36328).exports
