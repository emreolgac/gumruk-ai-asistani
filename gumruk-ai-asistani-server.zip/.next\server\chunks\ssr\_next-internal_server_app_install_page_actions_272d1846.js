module.exports=[60945,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_install_page_actions_272d1846.js.map