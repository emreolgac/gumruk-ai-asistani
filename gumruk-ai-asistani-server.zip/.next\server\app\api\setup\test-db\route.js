var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/setup/test-db/route.js")
R.c("server/chunks/[root-of-the-server]__7e995e2d._.js")
R.c("server/chunks/[root-of-the-server]__6ac8ec31._.js")
R.c("server/chunks/_next-internal_server_app_api_setup_test-db_route_actions_3616469d.js")
R.m(89772)
module.exports=R.m(89772).exports
