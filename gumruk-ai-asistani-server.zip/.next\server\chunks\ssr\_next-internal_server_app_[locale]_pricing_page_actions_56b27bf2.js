module.exports=[2347,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_pricing_page_actions_56b27bf2.js.map