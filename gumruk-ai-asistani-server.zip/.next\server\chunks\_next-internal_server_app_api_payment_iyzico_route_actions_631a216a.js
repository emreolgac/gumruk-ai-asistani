module.exports=[16303,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_payment_iyzico_route_actions_631a216a.js.map