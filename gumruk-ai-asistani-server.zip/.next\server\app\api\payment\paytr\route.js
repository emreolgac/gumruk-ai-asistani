var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/payment/paytr/route.js")
R.c("server/chunks/[root-of-the-server]__56855591._.js")
R.c("server/chunks/[root-of-the-server]__6ac8ec31._.js")
R.c("server/chunks/_next-internal_server_app_api_payment_paytr_route_actions_2fd38f30.js")
R.m(79704)
module.exports=R.m(79704).exports
