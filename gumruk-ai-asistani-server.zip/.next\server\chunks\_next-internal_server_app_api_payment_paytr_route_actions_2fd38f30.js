module.exports=[27739,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_payment_paytr_route_actions_2fd38f30.js.map