var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/analyze/route.js")
R.c("server/chunks/[externals]_next_dist_2db83349._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_2f6e8818.js")
R.c("server/chunks/[root-of-the-server]__41e65cf9._.js")
R.c("server/chunks/[root-of-the-server]__6ac8ec31._.js")
R.c("server/chunks/_next-internal_server_app_api_analyze_route_actions_487cf259.js")
R.m(26794)
module.exports=R.m(26794).exports
