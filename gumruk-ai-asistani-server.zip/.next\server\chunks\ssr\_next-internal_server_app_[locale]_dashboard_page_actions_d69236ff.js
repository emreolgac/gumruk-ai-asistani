module.exports=[60719,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_dashboard_page_actions_d69236ff.js.map