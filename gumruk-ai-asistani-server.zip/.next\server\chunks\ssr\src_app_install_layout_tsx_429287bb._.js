module.exports=[10704,a=>{"use strict";var b=a.i(7997);function c({children:a}){return(0,b.jsx)("html",{lang:"tr",children:(0,b.jsx)("body",{children:a})})}a.s(["default",()=>c])}];

//# sourceMappingURL=src_app_install_layout_tsx_429287bb._.js.map