var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/payment/iyzico/route.js")
R.c("server/chunks/[root-of-the-server]__02a9c28f._.js")
R.c("server/chunks/[root-of-the-server]__6ac8ec31._.js")
R.c("server/chunks/_next-internal_server_app_api_payment_iyzico_route_actions_631a216a.js")
R.m(53757)
module.exports=R.m(53757).exports
