module.exports=[22173,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_setup_save-config_route_actions_ddb0b35b.js.map