module.exports=[27572,a=>{"use strict";var b=a.i(7997);function c({children:a}){return(0,b.jsx)(b.Fragment,{children:a})}a.s(["default",()=>c])}];

//# sourceMappingURL=src_app_layout_tsx_cc8184fa._.js.map