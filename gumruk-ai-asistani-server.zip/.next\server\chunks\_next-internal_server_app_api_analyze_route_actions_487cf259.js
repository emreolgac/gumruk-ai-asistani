module.exports=[23124,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_analyze_route_actions_487cf259.js.map